---
name: Bug report
about: Create a report to help Tippy.js improve
title: ''
labels: "\U0001F41B bug, \U0001F6A7 unconfirmed"
assignees: ''
---

## Bug description

A clear and concise description of what the bug is.

## Reproduction

<!-- Please create a CodePen to reproduce the bug. It can be difficult to understand the problem otherwise. It should be reproduced exclusively using Tippy.js on CodePen. -->

CodePen link: https://codepen.io/atomiks/pen/yvwQyZ

const redirects = new Map();
redirects.set('/all-options/', '/all-props/');

export default redirects;
